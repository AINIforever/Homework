//
//  CalculatorBrain.h
//  Calculator2
//
//  Created by Woo on 18/5/20.
//  Copyright © 2018年 Woo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CalculatorBrain : NSObject
-(void)pushOperand:(double)operand;
-(double)performOperation:(NSString *)operation;
-(double)popOperand;

@end
