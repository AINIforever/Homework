//
//  ViewController.h
//  Calculator2
//
//  Created by Woo on 18/5/20.
//  Copyright © 2018年 Woo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *display;
- (IBAction)digitPressed:(UIButton *)sender;

- (IBAction)operationPressed:(UIButton *)sender;
@end

