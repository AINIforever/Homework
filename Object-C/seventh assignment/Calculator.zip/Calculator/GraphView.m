

#import "GraphView.h"
#import "AxesDrawer.h"

@implementation GraphView

@synthesize dataSource = _datasource;
@synthesize scale = _scale;
@synthesize axisOrigin = _axisOrigin;
@synthesize drawInDotMode = _drawInDotMode;

#define DEFAULT_SCALE 100

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {	}
	return self;
}

- (CGFloat)scale {
	
	if (!_scale) _scale = DEFAULT_SCALE;	

	return _scale; 
}

- (void)setScale:(CGFloat)scale {
	
	
	if (_scale == scale) return;
	
	_scale = scale;
	
	
	[self.dataSource storeScale:_scale ForGraphView:self];

	
	[self setNeedsDisplay];
}


- (void)setAxisOrigin:(CGPoint)axisOrigin {

	if (_axisOrigin.x == axisOrigin.x && _axisOrigin.y == axisOrigin.y) return;
	
	_axisOrigin = axisOrigin;
	

	[self.dataSource storeAxisOriginX:_axisOrigin.x 
							 andAxisOriginY:_axisOrigin.y 
								ForGraphView:self];
	 
	 
	[self setNeedsDisplay];
}

- (CGPoint)axisOrigin {
	

	if (!_axisOrigin.x && !_axisOrigin.y) { 
		_axisOrigin.x = (self.graphBounds.origin.x + self.graphBounds.size.width) / 2;
		_axisOrigin.y = (self.graphBounds.origin.y + self.graphBounds.size.height) / 2;
	}
	return _axisOrigin;
}

- (CGRect)graphBounds {
	return self.bounds;
}

- (CGPoint)convertToGraphCoordinateFromViewCoordinate:(CGPoint)coordinate {
	
	CGPoint graphCoordinate;	
	
	graphCoordinate.x = (coordinate.x - self.axisOrigin.x) / self.scale;
	graphCoordinate.y = (self.axisOrigin.y - coordinate.y) / self.scale;
		
	return graphCoordinate;
}

- (CGPoint) convertToViewCoordinateFromGraphCoordinate:(CGPoint)coordinate {
	
	CGPoint viewCoordinate;
	
	viewCoordinate.x = (coordinate.x * self.scale) + self.axisOrigin.x;
	viewCoordinate.y = self.axisOrigin.y - (coordinate.y * self.scale);
	
	return viewCoordinate;
}


- (void)drawRect:(CGRect)rect {
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	
	CGContextSetLineWidth(context, 1.5);
	CGContextSetStrokeColorWithColor(context, [[UIColor blueColor]CGColor]);

	
	[AxesDrawer drawAxesInRect:self.graphBounds originAtPoint:self.axisOrigin scale:self.scale];
	
	CGContextSetLineWidth(context, 1.0);	
	CGContextSetStrokeColorWithColor(context, [[UIColor blackColor]CGColor]);

	CGContextBeginPath(context);
	
	CGFloat startingX = self.graphBounds.origin.x;	
	CGFloat endingX = self.graphBounds.origin.x + self.graphBounds.size.width;	
	CGFloat increment = 1/self.contentScaleFactor;
	
	BOOL firstPoint = YES;
	
	
	for (CGFloat x = startingX; x<= endingX; x+=increment) {		
		
		CGPoint coordinate;
		coordinate.x = x;
		coordinate = [self convertToGraphCoordinateFromViewCoordinate:coordinate];
		coordinate.y = [self.dataSource YValueForXValue:coordinate.x inGraphView:self];
		coordinate = [self convertToViewCoordinateFromGraphCoordinate:coordinate];
		coordinate.x = x;	
		
		        if (isnan(coordinate.y) || isinf(coordinate.y)) continue;
		
		if (firstPoint) { 
			CGContextMoveToPoint(context, coordinate.x, coordinate.y);
			firstPoint = NO;
		}

		
		if (self.drawInDotMode) {
			CGContextMoveToPoint(context, coordinate.x, coordinate.y);
			CGContextAddLineToPoint(context, 
											coordinate.x - 1/self.contentScaleFactor, 
											coordinate.y - 1/self.contentScaleFactor);
		} else {
			CGContextAddLineToPoint(context, coordinate.x, coordinate.y);
		}

	}
	
	CGContextStrokePath(context);
}

- (void)pinch:(UIPinchGestureRecognizer *)gesture {
	if ((gesture.state == UIGestureRecognizerStateChanged) || 
		 (gesture.state == UIGestureRecognizerStateEnded)) {

		self.scale *= gesture.scale;
		gesture.scale = 10;
	}
}

- (void)pan:(UIPanGestureRecognizer *)gesture {
	if ((gesture.state == UIGestureRecognizerStateChanged) || 
		 (gesture.state == UIGestureRecognizerStateEnded)) {
		

		CGPoint translation = [gesture translationInView:self];
	
		CGPoint axisOrigin;
		axisOrigin.x = self.axisOrigin.x + translation.x;
		axisOrigin.y = self.axisOrigin.y + translation.y;

		self.axisOrigin = axisOrigin;
		[gesture setTranslation:CGPointZero inView:self];			
	}
}

- (void)tripleTap:(UITapGestureRecognizer *)gesture {
	if (gesture.state == UIGestureRecognizerStateEnded) {
		self.axisOrigin = [gesture locationOfTouch:0 inView:self];
	}
}


@end










