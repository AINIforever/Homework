
#import "GraphViewController.h"
#import "CalculatorBrain.h"
#import "GraphView.h"
#import "CalculatorViewController.h"

@interface GraphViewController () <GraphViewDataSource, MasterViewControllerPopoverDelegate>

@property (nonatomic, weak) IBOutlet GraphView *graphView;
@property (weak, nonatomic) IBOutlet UIToolbar *toolbar;

@property (strong, nonatomic) UIPopoverController *popover;

@end

@implementation GraphViewController

@synthesize program = _program;
@synthesize graphView = _graphView;
@synthesize toolbar = _toolbar;
@synthesize popover = _popover;

@synthesize masterViewController = _masterViewController;


- (id)masterViewController {
	return [self.splitViewController.viewControllers objectAtIndex:0];	
}

- (void)awakeFromNib {
	[super awakeFromNib];
	self.splitViewController.delegate = self;
	self.splitViewController.presentsWithGesture = NO;	
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return YES;
}

- (BOOL)splitViewController:(UISplitViewController *)svc 
	shouldHideViewController:(UIViewController *)vc 
				  inOrientation:(UIInterfaceOrientation)orientation {	
	
	return UIInterfaceOrientationIsPortrait(orientation);
}

- (void)splitViewController:(UISplitViewController *)svc 
	  willHideViewController:(UIViewController *)aViewController 
			 withBarButtonItem:(UIBarButtonItem *)barButtonItem 
		 forPopoverController:(UIPopoverController *)pc {

	barButtonItem.title = aViewController.title;
	

	
	barButtonItem.target = self;
	barButtonItem.action = @selector(barButtonPressed:);

	NSMutableArray *toolbarItems = [self.toolbar.items mutableCopy];
	[toolbarItems insertObject:barButtonItem atIndex:0];
	self.toolbar.items = toolbarItems;	
	
}


- (void)barButtonPressed:(id) sender {	

  	
   [self performSegueWithIdentifier:@"ShowCalculator" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
	[segue.destinationViewController setPopoverDelegate:self];	
	self.popover = ((UIStoryboardPopoverSegue *)segue).popoverController;
}

- (void) splitViewController:(UISplitViewController *)svc 
		willShowViewController:(UIViewController *)aViewController 
	invalidatingBarButtonItem:(UIBarButtonItem *)barButtonItem {
	
	// Hide the bar button item on the detail controller
	NSMutableArray *toolbarItems = [self.toolbar.items mutableCopy];
	[toolbarItems removeObject:barButtonItem];
	self.toolbar.items = toolbarItems;
	
	if (self.popover) [self.popover dismissPopoverAnimated:YES];
	
}

- (void)refreshProgramDependancies {

	if (! self.program) return;
	

	if (! self.graphView) return;
	
	NSString *program = [CalculatorBrain descriptionOfProgram:self.program];
	

	float scale = [[NSUserDefaults standardUserDefaults] 
						floatForKey:[@"scale." stringByAppendingString:program]];	
	

	float xAxisOrigin = [[NSUserDefaults standardUserDefaults] 
								floatForKey:[@"x." stringByAppendingString:program]];
	

	float yAxisOrigin = [[NSUserDefaults standardUserDefaults]
								floatForKey:[@"y." stringByAppendingString:program]];

	if (scale) self.graphView.scale = scale;
	
	if (xAxisOrigin && yAxisOrigin) {
		
		CGPoint axisOrigin;
		
		axisOrigin.x = xAxisOrigin;
		axisOrigin.y = yAxisOrigin;
		
		self.graphView.axisOrigin = axisOrigin;
	}
	
	[self.graphView setNeedsDisplay];
	
}

- (void) setProgram:(id)program {
	
	_program = program;
	
	// We want to set the title of the controller if the program changes
	self.title = [NSString stringWithFormat:@"y = %@", 
					  [CalculatorBrain descriptionOfProgram:self.program]];
} 


- (void) setGraphView:(GraphView *)graphView {
	_graphView = graphView;
	self.graphView.dataSource = self;
	
	// enable pinch gesture in the GraphView using pinch: handler
	[self.graphView addGestureRecognizer:[[UIPinchGestureRecognizer alloc] 
													  initWithTarget:self.graphView 
													  action:@selector(pinch:)]];
	
	// enable pan gesture in the GraphView using pan: handler
	[self.graphView addGestureRecognizer:[[UIPanGestureRecognizer alloc]
													  initWithTarget:self.graphView
													  action:@selector(pan:)]];
	
	
	UITapGestureRecognizer *tapGestureRecognizer = 
	[[UITapGestureRecognizer alloc] initWithTarget:self.graphView 
														 action:@selector(tripleTap:)];	
	tapGestureRecognizer.numberOfTapsRequired = 3;
	[self.graphView addGestureRecognizer:tapGestureRecognizer];	
	
	
	[self refreshProgramDependancies];
}

- (IBAction)drawModeSwitched:(id)sender {
	self.graphView.drawInDotMode = [(UISwitch *)sender isOn];
	[self.graphView setNeedsDisplay];	
}

- (void)storeScale:(float)scale ForGraphView:(GraphView *)sender {
	
	[[NSUserDefaults standardUserDefaults] 
	 setFloat:scale forKey:[@"scale." stringByAppendingString:
									[CalculatorBrain descriptionOfProgram:self.program]]];	

	[[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)storeAxisOriginX:(float)x andAxisOriginY:(float)y ForGraphView:(GraphView *)sender {
	
	
	NSString *program = [CalculatorBrain descriptionOfProgram:self.program];
	
	
	[[NSUserDefaults standardUserDefaults] setFloat:x 
														  forKey:[@"x." stringByAppendingString:program]];
	
	[[NSUserDefaults standardUserDefaults] setFloat:y 
														  forKey:[@"y." stringByAppendingString:program]];
	

	[[NSUserDefaults standardUserDefaults] synchronize];
	
}

- (float)YValueForXValue:(float)xValue inGraphView:(GraphView *)sender {
		id yValue = [CalculatorBrain runProgram:self.program usingVariableValues:
					 [NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:xValue] 
														  forKey:@"x"]];
	
	return ((NSNumber *)yValue).floatValue;	
}


- (void)viewDidUnload {
	[self setToolbar:nil];
	[super viewDidUnload];
}


@end
