

#import "CalculatorViewController.h"
#import "GraphViewController.h"

@interface CalculatorViewController ()

@property (nonatomic) BOOL userIsInTheMiddleOfEnteringNumber;
@property (nonatomic, strong) NSDictionary *testVariableValues;
@property (nonatomic, strong) CalculatorBrain *brain;

@end

@implementation CalculatorViewController

@synthesize display = _display;
@synthesize calculation = _calculation;
@synthesize variables = _variables;
@synthesize popoverDelegate = _popoverDelegate;
@synthesize brain = _brain;

@synthesize userIsInTheMiddleOfEnteringNumber;

@synthesize testVariableValues = _testVariableValues;

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return self.splitViewController ? 
	YES : UIInterfaceOrientationIsPortrait(toInterfaceOrientation);
}


- (GraphViewController *)graphViewController {
	return self.popoverDelegate ? 
	self.popoverDelegate :[self.splitViewController.viewControllers lastObject];
}


- (CalculatorBrain *)brain {
	if (self.popoverDelegate) _brain = [[self.popoverDelegate masterViewController] brain];
	if (!_brain) _brain = [[CalculatorBrain alloc] init];
	return _brain;
}


- (void)setBrain:(CalculatorBrain *)brain {
	_brain = brain;
}

- (NSDictionary *)testVariableValues {
	if (!_testVariableValues) {
		_testVariableValues = [NSDictionary dictionaryWithObjectsAndKeys:
									  [NSNumber numberWithDouble:0], @"x",
									  [NSNumber numberWithDouble:4.8], @"a",
									  [NSNumber numberWithDouble:0], @"b", nil];
	}
	return _testVariableValues;
}

- (NSDictionary *)programVariableValues {   
	
	NSArray *variableArray = 
	[[CalculatorBrain variablesUsedInProgram:self.brain.program] allObjects];
	
	return [self.testVariableValues dictionaryWithValuesForKeys:variableArray];
}

-(void)synchronizeView {   
	
	id result = [CalculatorBrain runProgram:self.brain.program 
							  usingVariableValues:self.testVariableValues];   

	if ([result isKindOfClass:[NSString class]])    self.display.text = result;
	else self.display.text = [NSString stringWithFormat:@"%g", [result doubleValue]];
 
	self.calculation.text = 
	[CalculatorBrain descriptionOfProgram:self.brain.program];
		self.variables.text = [[[[[[[self programVariableValues] description]
										stringByReplacingOccurrencesOfString:@"{" withString:@""]
									  stringByReplacingOccurrencesOfString:@"}" withString:@""]
									 stringByReplacingOccurrencesOfString:@";" withString:@""]
									stringByReplacingOccurrencesOfString:@"\"" withString:@""]
								  stringByReplacingOccurrencesOfString:@"<null>" withString:@"0"];
	
	self.userIsInTheMiddleOfEnteringNumber = NO;
}


- (IBAction)digitPressed:(UIButton *)sender {
	NSString *digit = [sender currentTitle];
	
	if (self.userIsInTheMiddleOfEnteringNumber) {
		self.display.text = [self.display.text stringByAppendingString:digit]; 
	} else {
		self.display.text = digit;
		self.userIsInTheMiddleOfEnteringNumber = YES;
	}    
}

- (IBAction)operationPressed:(UIButton *)sender {
	
	if (self.userIsInTheMiddleOfEnteringNumber) {
		[self enterPressed];
	}	
	
	[self.brain pushOperation:[sender currentTitle]];
	[self synchronizeView];	
}

- (IBAction)enterPressed {
	[self.brain pushOperand:[self.display.text doubleValue]];
	[self synchronizeView];	
}

- (IBAction)pointPressed {  
	
	if (!self.userIsInTheMiddleOfEnteringNumber) {
		self.display.text = @"0.";		
	} else {
		NSRange range = [self.display.text rangeOfString:@"."]; 		
		if (range.location == NSNotFound) {
			self.display.text = [self.display.text stringByAppendingString:@"."];
		}			
	}        
	self.userIsInTheMiddleOfEnteringNumber = YES;    
}

- (IBAction)clearPressed {
	[self.brain empty];
	[self synchronizeView];	
}

- (IBAction)signChangePressed:(UIButton *)sender {
	
	if (self.userIsInTheMiddleOfEnteringNumber) {        
		if ([[self.display.text substringToIndex:1] isEqualToString:@"-"]) {            
			self.display.text = [self.display.text substringFromIndex:1];
		} else {
			self.display.text = [@"-" stringByAppendingString:self.display.text]; 
		}
	} else {
		[self operationPressed:sender];
	}    
}

- (IBAction)variablePressed:(UIButton *)sender {
	[self.brain pushVariable:sender.currentTitle];
	[self synchronizeView];
}

- (IBAction)undoPressed {
	if (self.userIsInTheMiddleOfEnteringNumber) {
		self.display.text =[self.display.text substringToIndex:
								  [self.display.text length] - 1]; 
				if ( [self.display.text isEqualToString:@""]
			 || [self.display.text isEqualToString:@"-"]) {
			
			[self synchronizeView];     
		}   
	} else {
		[self.brain removeLastItem];
		[self synchronizeView];
	}   
}

- (IBAction)drawGraphPressed {
	
	if ([self graphViewController]) {
		[[self graphViewController] setProgram:self.brain.program];
		[[self graphViewController] refreshProgramDependancies];
	} else {
		[self performSegueWithIdentifier:@"ShowGraph" sender:self];
	}
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
	[segue.destinationViewController setProgram:self.brain.program];
}

- (IBAction)test1Pressed {
	self.testVariableValues = [NSDictionary dictionaryWithObjectsAndKeys:
										[NSNumber numberWithDouble:-4], @"x",
										[NSNumber numberWithDouble:3], @"a",
										[NSNumber numberWithDouble:4], @"b", nil];
	[self synchronizeView];
}

- (IBAction)test2Pressed {
	self.testVariableValues = [NSDictionary dictionaryWithObjectsAndKeys:
										[NSNumber numberWithDouble:-5], @"x", nil];
	[self synchronizeView]; 
}

- (IBAction)testNilPressed {
	self.testVariableValues = nil;  
	[self synchronizeView];
}

- (IBAction)brainPressed {
	
	CalculatorBrain *testBrain = [self brain];
	

	[testBrain empty];
	[testBrain pushOperand:3];
	[testBrain pushOperand:5];
	[testBrain pushOperand:6];
	[testBrain pushOperand:7];
	[testBrain pushOperation:@"+"];
	[testBrain pushOperation:@"*"];
	[testBrain pushOperation:@"-"];
	
	[testBrain pushOperand:3];
	[testBrain pushOperand:5];
	[testBrain pushOperation:@"+"];
	[testBrain pushOperation:@"sqrt"];
	

	[testBrain pushOperand:3];
	[testBrain pushOperation:@"sqrt"];
	[testBrain pushOperation:@"sqrt"];
	

	[testBrain pushOperand:3];
	[testBrain pushOperand:5];
	[testBrain pushOperation:@"sqrt"];
	[testBrain pushOperation:@"+"];
	
	[testBrain pushOperation:@"?"];
	[testBrain pushVariable:@"r"];
	[testBrain pushVariable:@"r"];
	[testBrain pushOperation:@"*"];
	[testBrain pushOperation:@"*"];
	
	[testBrain pushVariable:@"a"];
	[testBrain pushVariable:@"a"];
	[testBrain pushOperation:@"*"];
	[testBrain pushVariable:@"b"];
	[testBrain pushVariable:@"b"];
	[testBrain pushOperation:@"*"];
	[testBrain pushOperation:@"+"];
	[testBrain pushOperation:@"sqrt"];
	
	NSLog(@"Program is :%@",[CalculatorBrain descriptionOfProgram:[testBrain program]]);
	[testBrain empty];
}

- (void)viewDidAppear:(BOOL)animated {
	[self synchronizeView];
}

- (void)viewDidUnload {
	[super viewDidUnload];
}

@end
