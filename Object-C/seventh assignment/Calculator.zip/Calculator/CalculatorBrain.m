
#import "CalculatorBrain.h"

@interface CalculatorBrain()

@property (nonatomic, strong) NSMutableArray *programStack;


@end

@implementation CalculatorBrain

static NSDictionary *OPERAND_COUNTS;

@synthesize programStack = _programStack;

- (NSMutableArray *)programStack {
	if (_programStack == nil) _programStack = [[NSMutableArray alloc] init];
	return _programStack;
}

+ (NSDictionary *)operandCounts {
	if (OPERAND_COUNTS == nil) {
		OPERAND_COUNTS = [NSDictionary dictionaryWithObjectsAndKeys: 
								[NSNumber numberWithInt:0], @"π", 
								[NSNumber numberWithInt:1], @"sin",
								[NSNumber numberWithInt:1], @"cos", 
								[NSNumber numberWithInt:1], @"sqrt",
								[NSNumber numberWithInt:1], @"±", 
								[NSNumber numberWithInt:2], @"+", 
								[NSNumber numberWithInt:2], @"-", 
								[NSNumber numberWithInt:2], @"*", 
								[NSNumber numberWithInt:2], @"/", nil];
	}
	return OPERAND_COUNTS;
}

- (id)program {	
	return [self.programStack copy];
}

- (void)pushOperand:(double)operand {		
	[self.programStack addObject:[NSNumber numberWithDouble:operand]];    
}

- (void)pushVariable:(NSString *) variable {
	[self.programStack addObject:variable];	
}

- (void)pushOperation:(NSString *) operation {
	[self.programStack addObject:operation];	
}

- (id)performOperation:(NSString *)operation {	
	[self pushOperation:operation];
	return [[self class] runProgram:self.programStack];	
}

- (void)empty {
	self.programStack = nil;
}

- (void)removeLastItem {
	[self.programStack removeLastObject];
}

+ (BOOL)isNoOperandOperation:(NSString *)operation {
	
	return [[self operandCounts] objectForKey:operation] == [NSNumber numberWithInt:0];
}

+ (BOOL)isOneOperandOperation:(NSString *)operation {
	
	return [[self operandCounts] objectForKey:operation] == [NSNumber numberWithInt:1];
}

+ (BOOL)isTwoOperandOperation:(NSString *)operation {
	
	return [[self operandCounts] objectForKey:operation] == [NSNumber numberWithInt:2];
}

+ (BOOL)isOperation:(NSString *)operation {	
	
	// Check to see if it's in the operandCounts dictionary
	return [[self operandCounts] objectForKey:operation] != nil;
}

+ (BOOL)isValidProgram:(id)program {
	// It's valid if it's an NSArray
	return [program isKindOfClass:[NSArray class]];
}

+ (NSString *)deBracket:(NSString *)expression {
	
	NSString *description = expression;
	
	if ([expression hasPrefix:@"("] && [expression hasSuffix:@")"]) {
		description = [description substringFromIndex:1];
		description = [description substringToIndex:[description length] - 1];
	}	
	
	NSRange openBracket = [description rangeOfString:@"("];
	NSRange closeBracket = [description rangeOfString:@")"];
	
	if (openBracket.location <= closeBracket.location) return description;
	else return expression;	
}


+ (NSString *)descriptionOffTopOfStack:(NSMutableArray *)stack {
	
	NSString *description;
	
	
	id topOfStack = [stack lastObject];
	if (topOfStack) [stack removeLastObject]; else return @"";
	
	if ([topOfStack isKindOfClass:[NSNumber class]]) {
		return [topOfStack description];
	}		

	else if ([topOfStack isKindOfClass:[NSString class]]) {	
		
		if (![self isOperation:topOfStack] ||
			 [self isNoOperandOperation:topOfStack]) {	
			description = topOfStack;
		} 
		
		else if ([self isOneOperandOperation:topOfStack]) {
			NSString *x = [self deBracket:[self descriptionOffTopOfStack:stack]];
			description = [NSString stringWithFormat:@"%@(%@)", topOfStack, x];	
		}
		else if ([self isTwoOperandOperation:topOfStack]) {
			NSString *y = [self descriptionOffTopOfStack:stack];
			NSString *x = [self descriptionOffTopOfStack:stack];

			if ([topOfStack isEqualToString:@"+"] || [topOfStack isEqualToString:@"-"]) {
				description = [NSString stringWithFormat:@"(%@ %@ %@)",
					[self deBracket:x], topOfStack, [self deBracket:y]];
			} else if ([topOfStack isEqualToString:@"/"]) {
				description = [NSString stringWithFormat:@"%@ %@ (%@)", 
									x, topOfStack,[self deBracket:y]];
			}
			else {
			  description = [NSString stringWithFormat:@"%@ %@ %@",	x, topOfStack ,y];
			}
		}		
	}
	return description ;		
}

+ (NSString *)descriptionOfProgram:(id)program {	
	
	if (![self isValidProgram:program]) return @"Invalid program!";
	
	if ([program count] == 0) return @"0";
	
	NSMutableArray *stack= [program mutableCopy];
	NSMutableArray *expressionArray = [NSMutableArray array];
		  
	while (stack.count > 0) {
		[expressionArray addObject:[self deBracket:[self descriptionOffTopOfStack:stack]]];
	}

	return [expressionArray componentsJoinedByString:@","];		 
}

+ (id)popOperandOffProgramStack:(NSMutableArray *) stack {
	
	NSString * INSUFFICIENT_OPERANDS = @"Insufficient operands!";
	NSString * INVALID_OPERATION = @"Operation not implemented!";
	
	double result = 0;
	
	id topOfStack = [stack lastObject];
	if (topOfStack) [stack removeLastObject]; else return @"0";

	if ([topOfStack isKindOfClass:[NSNumber class]]) return topOfStack;		
	
	NSString *operation = topOfStack;

	if ([operation isEqualToString:@"π"]) { 
		result = M_PI;
	}
	else if ([self isOneOperandOperation:operation]) {
		id operand1 = [self popOperandOffProgramStack:stack];
		if ([operand1 isKindOfClass:[NSNumber class]]) {
			if ([operation isEqualToString:@"sin"]) {
				result = sin ([operand1 doubleValue]); 
			} else if ([operation isEqualToString:@"cos"]) {
				result = cos ([operand1 doubleValue]);
			} else if ([operation isEqualToString:@"sqrt"]) {
				result = sqrt([operand1 doubleValue]);
			} else if ([operation isEqualToString:@"±"]) {
				result = [operand1 doubleValue] * -1;	
			} 
		} else return INSUFFICIENT_OPERANDS;			
	}
	else if ([self isTwoOperandOperation:operation]) {
		id operand1 = [self popOperandOffProgramStack:stack];
		id operand2 = [self popOperandOffProgramStack:stack];
		if ([operand1 isKindOfClass:[NSNumber class]] &&
			 [operand2 isKindOfClass:[NSNumber class]]) {
			if ([operation isEqualToString:@"+"]) {
				result = [operand2 doubleValue] + [operand1 doubleValue]; 
			} else if ([@"*" isEqualToString:operation]) {
				result = [operand2 doubleValue] * [operand1 doubleValue];
			} else if ([operation isEqualToString:@"-"]) {
				result = [operand2 doubleValue] - [operand1 doubleValue];
			} else if ([operation isEqualToString:@"/"]) {
				result = [operand2 doubleValue] / [operand1 doubleValue];
			}
		} else return INSUFFICIENT_OPERANDS;
	} else return INVALID_OPERATION;
	
	return [NSNumber numberWithDouble:result];
}

+ (id)runProgram:(id)program {
	return [self runProgram:program usingVariableValues:nil];
}

+ (id)runProgram:(id)program 
usingVariableValues:(NSDictionary *)variableValues {
	if (![self isValidProgram:program]) return 0;
	
	NSMutableArray *stack= [program mutableCopy];

	for (int i=0; i < [stack count]; i++) {
		id obj = [stack objectAtIndex:i]; 

		if ([obj isKindOfClass:[NSString class]] && ![self isOperation:obj]) {	
			id value = [variableValues objectForKey:obj];
			if (![value isKindOfClass:[NSNumber class]]) {
				value = [NSNumber numberWithInt:0];
			}
			[stack replaceObjectAtIndex:i withObject:value];
		}		
	}
	return [self popOperandOffProgramStack:stack];	
}


+ (NSSet *)variablesUsedInProgram:(id)program {	

	if (![self isValidProgram:program]) return nil;
	
	NSMutableSet *variables = [NSMutableSet set];

	for (id obj in program) {
		if ([obj isKindOfClass:[NSString class]] && ![self isOperation:obj]) {
			[variables addObject:obj]; 	
		}
	}	
	if ([variables count] == 0) return nil; else return [variables copy];
}

@end
